# Unknown - Developer Portfolio

A professional, modern, and responsive developer portfolio website for **Piyush Gupta**, also known as **Unknown**.

![Portfolio Preview](https://img.shields.io/badge/React-18.2.0-61DAFB?style=for-the-badge&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.2.2-3178C6?style=for-the-badge&logo=typescript)
![Vite](https://img.shields.io/badge/Vite-5.0.8-646CFF?style=for-the-badge&logo=vite)

## ✨ Features

- 🎨 **Dark Mode Design** - Premium dark theme with gradient accents
- ⚡ **Smooth Animations** - Framer Motion powered transitions
- 📱 **Fully Responsive** - Optimized for all screen sizes
- 🎯 **Modern UI/UX** - Clean, professional design with gaming aesthetics
- 🚀 **Performance Optimized** - Fast loading with Vite
- 💼 **Professional Sections** - Home, About, Skills, Contact
- 📧 **Contact Form** - With validation and animations
- 🎮 **Gamer Vibes** - Subtle RGB effects and terminal-inspired design

## 🛠️ Tech Stack

- **React 18** - UI library
- **TypeScript** - Type-safe development
- **Vite** - Build tool and dev server
- **Framer Motion** - Animation library
- **CSS3** - Custom styling with modern features
- **Material Icons** - Icon library

## 📁 Project Structure

```
portfolio-project/
├── src/
│   ├── components/
│   │   ├── Navbar.tsx
│   │   ├── Navbar.css
│   │   ├── Hero.tsx
│   │   ├── Hero.css
│   │   ├── About.tsx
│   │   ├── About.css
│   │   ├── Skills.tsx
│   │   ├── Skills.css
│   │   ├── Contact.tsx
│   │   ├── Contact.css
│   │   ├── Footer.tsx
│   │   └── Footer.css
│   ├── pages/
│   │   └── Home.tsx
│   ├── styles/
│   │   └── global.css
│   ├── App.tsx
│   └── main.tsx
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- Node.js 16.0 or higher
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd portfolio-project
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to:
```
http://localhost:3000
```

## 📦 Building for Production

Build the project for production:

```bash
npm run build
```

Preview the production build:

```bash
npm run preview
```

## 🚀 Deploying to Vercel

### Option 1: Using Vercel CLI

1. Install Vercel CLI:
```bash
npm i -g vercel
```

2. Deploy:
```bash
vercel
```

### Option 2: Using Vercel Dashboard

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your repository
5. Vercel will auto-detect Vite and deploy

### Environment Configuration

No environment variables required for basic deployment.

## 🎨 Customization

### Colors

Edit `src/styles/global.css` to customize the color scheme:

```css
:root {
  --accent-primary: #00d9ff;
  --accent-secondary: #7000ff;
  /* Add your custom colors */
}
```

### Content

- **Hero Section**: Edit `src/components/Hero.tsx`
- **About Section**: Edit `src/components/About.tsx`
- **Skills**: Edit `src/components/Skills.tsx`
- **Contact Info**: Edit `src/components/Contact.tsx`

### Profile Image

Replace the placeholder image URL in `Hero.tsx`:

```tsx
<img
  src="YOUR_IMAGE_URL"
  alt="Piyush Gupta"
/>
```

## 📱 Sections

### 🏠 Home (Hero)
- Animated typing effect
- Profile image with glow
- Social links
- CTA buttons

### 👤 About
- Professional introduction
- Core competencies cards
- Philosophy section
- Responsive grid layout

### 🧠 Skills
- Programming languages checklist
- Tools & technologies
- Core competencies
- Clean, no-progress-bar design

### 📬 Contact
- Validated contact form
- Social links
- Professional layout
- Success/error handling

## 🎯 Design Philosophy

This portfolio combines:
- **Professional aesthetics** for corporate readiness
- **Gaming vibes** with RGB accents and neon colors
- **Modern UX** with smooth animations
- **Clean code** with TypeScript safety
- **Performance** optimized bundle size

## 📄 License

MIT License - feel free to use this for your own portfolio!

## 👤 Author

**Piyush Gupta (Unknown)**

- GitHub: [@your-github](https://github.com)
- Email: piyush@example.com
- Discord: Your#Discord

## 🙏 Acknowledgments

- Design inspiration from modern portfolio trends
- Icons from Google Material Icons
- Animations powered by Framer Motion

---

Made with ❤️ and lots of coffee by Unknown