# 🚀 Quick Start Guide

Get your portfolio running in 5 minutes!

## Step 1: Setup (2 minutes)

```bash
# Navigate to project
cd portfolio-project

# Install dependencies
npm install
```

## Step 2: Start Development Server (30 seconds)

```bash
npm run dev
```

Open **http://localhost:3000** in your browser.

## Step 3: Customize Your Content (2 minutes)

### Update Your Name & Info

**File**: `src/components/Hero.tsx`

```tsx
// Line 60-65: Update your name
<h1 className="hero-name">
  Your Name Here  {/* Change this */}
</h1>
<h2 className="hero-subtitle">
  Also known as <span className="gradient-text">Your Alias</span>
</h2>
```

**File**: `src/components/About.tsx`

```tsx
// Line 40-45: Update your intro
<p>
  I'm [Your Name], known in the digital world as <strong>[Your Alias]</strong>. 
  [Your story here...]
</p>
```

### Update Your Skills

**File**: `src/components/Skills.tsx`

```tsx
// Line 8-15: Add/remove programming languages
const programmingLanguages = [
  { name: 'JavaScript', icon: 'javascript' },
  { name: 'Your Language', icon: 'code' },
  // Add more...
];

// Line 17-26: Add/remove tools
const tools = [
  { name: 'Your Tool', icon: 'build' },
  // Add more...
];
```

### Update Contact Info

**File**: `src/components/Contact.tsx`

```tsx
// Line 91-103: Update social links
const socialLinks = [
  {
    name: 'GitHub',
    icon: 'code',
    url: 'https://github.com/yourusername',  // Update this
  },
  {
    name: 'Email',
    url: 'mailto:your.email@example.com',    // Update this
  },
  // Add more...
];
```

**File**: `src/components/Footer.tsx`

```tsx
// Line 11-15: Update footer links
const socialLinks = [
  { icon: 'code', url: 'https://github.com/yourusername' },  // Update
  { icon: 'email', url: 'mailto:your.email@example.com' },   // Update
  // Update more...
];
```

## Step 4: Add Your Photo (Optional, 30 seconds)

### Option A: Use your own image
1. Add your image to `src/assets/images/profile.jpg`
2. Update `src/components/Hero.tsx`:
```tsx
// Replace line 74
import profileImg from '../assets/images/profile.jpg';

<img
  src={profileImg}  // Use your image
  alt="Your Name"
/>
```

### Option B: Keep the generated avatar
- Edit the seed in the URL to generate different avatar
- Change `seed=Unknown` to `seed=YourName`

## Step 5: Test & Build (30 seconds)

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

Visit **http://localhost:4173** to see the production version.

## Step 6: Deploy to Vercel (1 minute)

```bash
# Push to GitHub
git add .
git commit -m "Initial portfolio setup"
git push

# Deploy (if using Vercel CLI)
npm i -g vercel
vercel
```

Or use the Vercel dashboard:
1. Go to [vercel.com](https://vercel.com)
2. Import your GitHub repo
3. Click Deploy
4. Done! 🎉

---

## Common Customizations

### Change Colors

**File**: `src/styles/global.css`

```css
:root {
  --accent-primary: #00d9ff;    /* Change to your color */
  --accent-secondary: #7000ff;  /* Change to your color */
}
```

### Change Typing Effect Roles

**File**: `src/components/Hero.tsx`

```tsx
// Line 8-13
const roles = [
  'Your Title 1',
  'Your Title 2',
  'Your Title 3',
];
```

### Update Tagline

**File**: `src/components/Hero.tsx`

```tsx
// Line 85-89
<p className="hero-tagline">
  Your professional tagline here...
</p>
```

---

## Need More Help?

📖 **Full Documentation**: See `DOCUMENTATION.md`
🚀 **Deployment Guide**: See `DEPLOYMENT.md`
📋 **README**: See `README.md`

---

## Checklist Before Going Live

- [ ] Updated name and alias
- [ ] Updated all social links
- [ ] Updated email addresses
- [ ] Customized skills list
- [ ] Added profile photo (optional)
- [ ] Updated tagline and about text
- [ ] Changed colors (optional)
- [ ] Tested on mobile
- [ ] Tested contact form
- [ ] Built and previewed
- [ ] Pushed to GitHub
- [ ] Deployed to Vercel

---

## What's Next?

1. **Share your portfolio**
   - Add to LinkedIn
   - Add to resume
   - Share on Twitter/X
   - Add to GitHub profile

2. **Keep it updated**
   - Add new skills as you learn
   - Update projects
   - Refresh content regularly

3. **Monitor performance**
   - Check Vercel Analytics
   - Run Lighthouse audits
   - Get feedback from peers

---

**You're all set! 🎉**

Your portfolio is ready to impress potential employers and clients.

Need help? Open an issue on GitHub or check the documentation!