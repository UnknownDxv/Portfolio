import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import './Hero.css';

const Hero: React.FC = () => {
  const [typedText, setTypedText] = useState('');
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const roles = [
    'Full-Stack Developer',
    'Discord Bot Developer',
    'Gamer',
    'Problem Solver',
  ];

  // Typing animation effect
  useEffect(() => {
    const currentRole = roles[currentRoleIndex];
    const typingSpeed = isDeleting ? 50 : 100;

    const timeout = setTimeout(() => {
      if (!isDeleting && typedText === currentRole) {
        // Pause before deleting
        setTimeout(() => setIsDeleting(true), 2000);
      } else if (isDeleting && typedText === '') {
        // Move to next role
        setIsDeleting(false);
        setCurrentRoleIndex((prev) => (prev + 1) % roles.length);
      } else {
        // Continue typing or deleting
        setTypedText(
          isDeleting
            ? currentRole.substring(0, typedText.length - 1)
            : currentRole.substring(0, typedText.length + 1)
        );
      }
    }, typingSpeed);

    return () => clearTimeout(timeout);
  }, [typedText, isDeleting, currentRoleIndex]);

  // Scroll down handler
  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="hero section">
      <div className="hero-container container">
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Profile Image */}
          <motion.div
            className="hero-image-wrapper"
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="hero-image">
              <img
                src="https://api.dicebear.com/7.x/avataaars/svg?seed=Unknown&backgroundColor=00d9ff"
                alt="Piyush Gupta"
              />
              <div className="image-glow"></div>
            </div>
          </motion.div>

          {/* Text Content */}
          <motion.div
            className="hero-text"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <h3 className="hero-greeting">Hi, I'm</h3>
            <h1 className="hero-name">
              Piyush Gupta
            </h1>
            <h2 className="hero-subtitle">
              Also known as <span className="gradient-text">Unknown</span>
            </h2>

            {/* Animated Typing Text */}
            <div className="hero-typing">
              <span className="typing-text">{typedText}</span>
              <span className="typing-cursor">|</span>
            </div>

            {/* Tagline */}
            <p className="hero-tagline">
              Crafting elegant solutions through code, building powerful Discord bots,
              and bringing strategic gaming mindset to every challenge.
            </p>

            {/* CTA Buttons */}
            <div className="hero-buttons">
              <a href="#contact" className="btn btn-primary">
                <span className="material-icons">send</span>
                Get In Touch
              </a>
              <a href="#about" className="btn btn-outline">
                <span className="material-icons">person</span>
                Learn More
              </a>
            </div>

            {/* Social Links */}
            <div className="hero-social">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hero-social-link"
                aria-label="GitHub"
              >
                <span className="material-icons">code</span>
              </a>
              <a
                href="mailto:piyush@example.com"
                className="hero-social-link"
                aria-label="Email"
              >
                <span className="material-icons">email</span>
              </a>
              <a
                href="https://discord.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hero-social-link"
                aria-label="Discord"
              >
                <span className="material-icons">chat</span>
              </a>
            </div>
          </motion.div>
        </motion.div>

        {/* Scroll Down Indicator */}
        <motion.div
          className="scroll-indicator"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          onClick={scrollToAbout}
        >
          <span className="material-icons">keyboard_arrow_down</span>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;