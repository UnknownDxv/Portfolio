import React from 'react';
import { motion } from 'framer-motion';
import './Skills.css';

const Skills: React.FC = () => {
  // Skills data
  const programmingLanguages = [
    { name: 'JavaScript', icon: 'javascript' },
    { name: 'TypeScript', icon: 'code' },
    { name: 'Python', icon: 'code' },
    { name: 'HTML', icon: 'html' },
    { name: 'CSS', icon: 'css' },
    { name: 'SQLite', icon: 'storage' },
    { name: 'MongoDB', icon: 'storage' },
  ];

  const tools = [
    { name: 'Visual Studio Code', icon: 'code' },
    { name: 'Cursor', icon: 'edit' },
    { name: 'Git & GitHub', icon: 'source' },
    { name: 'Node.js', icon: 'dns' },
    { name: 'React', icon: 'web' },
    { name: 'Discord.js', icon: 'chat' },
    { name: 'Express.js', icon: 'api' },
    { name: 'REST APIs', icon: 'api' },
  ];

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section id="skills" className="skills section">
      <div className="container">
        <motion.h2
          className="section-title"
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          Skills & <span className="gradient-text">Expertise</span>
        </motion.h2>

        <div className="skills-content">
          {/* Programming Languages */}
          <motion.div
            className="skills-category card"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <div className="category-header">
              <div className="category-icon">
                <span className="material-icons">terminal</span>
              </div>
              <h3>Programming Languages</h3>
            </div>
            <div className="skills-list">
              {programmingLanguages.map((skill, index) => (
                <motion.div
                  key={index}
                  className="skill-item"
                  variants={itemVariants}
                  whileHover={{ x: 10, scale: 1.02 }}
                >
                  <div className="skill-check">
                    <span className="material-icons">check_circle</span>
                  </div>
                  <div className="skill-info">
                    <span className="skill-name">{skill.name}</span>
                  </div>
                  <div className="skill-icon">
                    <span className="material-icons">{skill.icon}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Tools & Technologies */}
          <motion.div
            className="skills-category card"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={containerVariants}
          >
            <div className="category-header">
              <div className="category-icon">
                <span className="material-icons">build</span>
              </div>
              <h3>Tools & Technologies</h3>
            </div>
            <div className="skills-list">
              {tools.map((tool, index) => (
                <motion.div
                  key={index}
                  className="skill-item"
                  variants={itemVariants}
                  whileHover={{ x: 10, scale: 1.02 }}
                >
                  <div className="skill-check">
                    <span className="material-icons">check_circle</span>
                  </div>
                  <div className="skill-info">
                    <span className="skill-name">{tool.name}</span>
                  </div>
                  <div className="skill-icon">
                    <span className="material-icons">{tool.icon}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Additional Competencies */}
          <motion.div
            className="competencies card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="category-header">
              <div className="category-icon">
                <span className="material-icons">auto_awesome</span>
              </div>
              <h3>Core Competencies</h3>
            </div>
            <div className="competencies-grid">
              <div className="competency-item">
                <span className="material-icons">speed</span>
                <span>Performance Optimization</span>
              </div>
              <div className="competency-item">
                <span className="material-icons">security</span>
                <span>Security Best Practices</span>
              </div>
              <div className="competency-item">
                <span className="material-icons">sync</span>
                <span>Asynchronous Programming</span>
              </div>
              <div className="competency-item">
                <span className="material-icons">groups</span>
                <span>Team Collaboration</span>
              </div>
              <div className="competency-item">
                <span className="material-icons">bug_report</span>
                <span>Debugging & Testing</span>
              </div>
              <div className="competency-item">
                <span className="material-icons">architecture</span>
                <span>System Architecture</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Skills;