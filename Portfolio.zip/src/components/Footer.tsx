import React from 'react';
import './Footer.css';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Contact', href: '#contact' },
  ];

  const socialLinks = [
    { icon: 'code', url: 'https://github.com', label: 'GitHub' },
    { icon: 'email', url: 'mailto:piyush@example.com', label: 'Email' },
    { icon: 'chat', url: 'https://discord.com', label: 'Discord' },
  ];

  return (
    <footer className="footer">
      <div className="footer-container container">
        {/* Footer Top */}
        <div className="footer-top">
          {/* Brand */}
          <div className="footer-brand">
            <h3 className="footer-logo">
              <span className="gradient-text">&lt;Unknown /&gt;</span>
            </h3>
            <p className="footer-tagline">
              Building elegant solutions, one line of code at a time.
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-links">
            <h4>Quick Links</h4>
            <ul>
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href}>
                    <span className="material-icons">arrow_forward</span>
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social Links */}
          <div className="footer-social-section">
            <h4>Connect With Me</h4>
            <div className="footer-social">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.url}
                  target={link.label !== 'Email' ? '_blank' : undefined}
                  rel={link.label !== 'Email' ? 'noopener noreferrer' : undefined}
                  className="footer-social-link"
                  aria-label={link.label}
                >
                  <span className="material-icons">{link.icon}</span>
                </a>
              ))}
            </div>
            <p className="footer-email">piyush@example.com</p>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom">
          <div className="footer-divider"></div>
          <div className="footer-copyright">
            <p>
              © {currentYear} <strong>Piyush Gupta (Unknown)</strong>. All rights reserved.
            </p>
            <p className="footer-note">
              Crafted with <span className="material-icons heart">favorite</span> and lots of coffee
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;