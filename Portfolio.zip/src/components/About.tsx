import React from 'react';
import { motion } from 'framer-motion';
import './About.css';

const About: React.FC = () => {
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  };

  return (
    <section id="about" className="about section">
      <div className="container">
        <motion.h2
          className="section-title"
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          About <span className="gradient-text">Me</span>
        </motion.h2>

        <motion.div
          className="about-content"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {/* Main Description */}
          <motion.div className="about-description card" variants={itemVariants}>
            <div className="about-icon">
              <span className="material-icons">psychology</span>
            </div>
            <h3>Passionate Developer</h3>
            <p>
              I'm Piyush Gupta, known in the digital world as <strong>Unknown</strong>. 
              My journey in programming began with a curiosity to understand how things work 
              and evolved into a passion for creating elegant, efficient solutions to complex problems.
            </p>
            <p>
              I believe that great code is not just about functionality—it's about crafting 
              experiences that are intuitive, powerful, and maintainable. Every line of code 
              I write is an opportunity to learn something new and push the boundaries of what's possible.
            </p>
          </motion.div>

          {/* Three Column Layout */}
          <div className="about-grid">
            {/* Discord Bot Development */}
            <motion.div className="about-card card" variants={itemVariants}>
              <div className="card-icon">
                <span className="material-icons">smart_toy</span>
              </div>
              <h3>Bot Development</h3>
              <p>
                Specializing in creating powerful Discord bots that enhance community 
                experiences. From moderation tools to custom integrations, I build 
                bots that are reliable, scalable, and user-friendly.
              </p>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Advanced automation</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Custom integrations</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Scalable architecture</span>
              </div>
            </motion.div>

            {/* Backend & Tools */}
            <motion.div className="about-card card" variants={itemVariants}>
              <div className="card-icon">
                <span className="material-icons">developer_mode</span>
              </div>
              <h3>Backend & Tools</h3>
              <p>
                Building robust backend systems and developer tools that power 
                applications. I focus on performance, security, and creating 
                APIs that developers love to work with.
              </p>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>RESTful API design</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Database optimization</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>CLI tool development</span>
              </div>
            </motion.div>

            {/* Gamer Mindset */}
            <motion.div className="about-card card" variants={itemVariants}>
              <div className="card-icon">
                <span className="material-icons">sports_esports</span>
              </div>
              <h3>Gamer Mindset</h3>
              <p>
                Gaming has taught me strategic thinking, adaptability, and persistence. 
                I apply the same problem-solving approach from gaming to development—
                analyzing challenges, optimizing strategies, and never giving up.
              </p>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Strategic problem-solving</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Quick adaptation</span>
              </div>
              <div className="card-highlight">
                <span className="material-icons">check_circle</span>
                <span>Team collaboration</span>
              </div>
            </motion.div>
          </div>

          {/* Philosophy */}
          <motion.div className="about-philosophy card" variants={itemVariants}>
            <div className="philosophy-icon">
              <span className="material-icons">auto_awesome</span>
            </div>
            <h3>My Philosophy</h3>
            <p>
              "Code is poetry written in logic." I approach every project with the mindset 
              that technology should empower people, not complicate their lives. Whether 
              it's a Discord bot serving thousands of users or a backend system processing 
              millions of requests, I strive to create solutions that are both powerful 
              and elegant.
            </p>
            <p>
              Continuous learning is at the core of who I am. The tech landscape evolves 
              rapidly, and I'm committed to staying ahead of the curve, experimenting with 
              new technologies, and sharing knowledge with the developer community.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;