import React, { useEffect } from 'react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Footer from './components/Footer';
import './styles/global.css';

const App: React.FC = () => {
  // Create particle effect
  useEffect(() => {
    const particlesContainer = document.getElementById('particles');
    if (!particlesContainer) return;

    // Create particles
    const particleCount = 50;
    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      
      // Random positioning
      particle.style.left = `${Math.random() * 100}%`;
      particle.style.top = `${Math.random() * 100}%`;
      
      // Random animation delay and duration
      particle.style.animationDelay = `${Math.random() * 15}s`;
      particle.style.animationDuration = `${10 + Math.random() * 10}s`;
      
      particlesContainer.appendChild(particle);
    }

    // Cleanup on unmount
    return () => {
      if (particlesContainer) {
        particlesContainer.innerHTML = '';
      }
    };
  }, []);

  return (
    <div className="app">
      {/* Animated Background */}
      <div className="animated-bg"></div>
      
      {/* Particles Effect */}
      <div id="particles" className="particles"></div>

      {/* Main Content */}
      <Navbar />
      <main>
        <Home />
      </main>
      <Footer />
    </div>
  );
};

export default App;