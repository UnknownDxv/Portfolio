# 🚀 Deployment Guide for Vercel

This guide will help you deploy your portfolio to Vercel in minutes.

## Prerequisites

- GitHub account
- Vercel account (free tier works great)
- Your portfolio code pushed to GitHub

## Method 1: Deploy via Vercel Dashboard (Recommended)

### Step 1: Push to GitHub

1. Create a new repository on GitHub
2. Initialize git in your project:
```bash
cd portfolio-project
git init
git add .
git commit -m "Initial commit: Portfolio website"
```

3. Push to GitHub:
```bash
git remote add origin <your-github-repo-url>
git branch -M main
git push -u origin main
```

### Step 2: Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **"Add New..."** → **"Project"**
3. Import your GitHub repository
4. Vercel will auto-detect the settings:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
5. Click **"Deploy"**
6. Wait 1-2 minutes for deployment to complete
7. Your site is live! 🎉

### Step 3: Custom Domain (Optional)

1. Go to your project settings on Vercel
2. Click **"Domains"**
3. Add your custom domain
4. Follow DNS configuration instructions

## Method 2: Deploy via Vercel CLI

### Step 1: Install Vercel CLI

```bash
npm i -g vercel
```

### Step 2: Login to Vercel

```bash
vercel login
```

### Step 3: Deploy

From your project directory:

```bash
vercel
```

Follow the prompts:
- Set up and deploy? **Y**
- Which scope? Select your account
- Link to existing project? **N**
- What's your project's name? **unknown-portfolio**
- In which directory is your code located? **./**

Your site will be deployed and you'll get a URL!

### Step 4: Deploy to Production

```bash
vercel --prod
```

## Environment Variables (If Needed)

If you add any API keys or environment variables later:

1. Go to Vercel Dashboard → Your Project → Settings → Environment Variables
2. Add your variables
3. Redeploy the project

## Automatic Deployments

Once connected to GitHub, Vercel will automatically:
- Deploy every push to the `main` branch (production)
- Create preview deployments for pull requests
- Show deployment status on GitHub

## Troubleshooting

### Build Failed

**Issue**: Build command failed
**Solution**: 
- Check that all dependencies are in `package.json`
- Run `npm install` and `npm run build` locally first
- Check build logs on Vercel dashboard

### 404 Errors on Routes

**Issue**: Getting 404 on page refresh
**Solution**: 
- The `vercel.json` file should handle this
- If not, add this to `vercel.json`:
```json
{
  "rewrites": [{ "source": "/(.*)", "destination": "/" }]
}
```

### Slow Initial Load

**Issue**: First load is slow
**Solution**:
- Enable Vercel's automatic image optimization
- Check bundle size with `npm run build`
- Consider lazy loading components

## Performance Optimization

### After Deployment

1. **Check Lighthouse Score**
   - Open Chrome DevTools
   - Go to Lighthouse tab
   - Run audit

2. **Enable Vercel Analytics** (Optional)
   ```bash
   npm i @vercel/analytics
   ```
   
   In `src/main.tsx`:
   ```tsx
   import { inject } from '@vercel/analytics';
   inject();
   ```

3. **Monitor Performance**
   - Go to Vercel Dashboard → Analytics
   - Track Core Web Vitals
   - Monitor visitor metrics

## Updating Your Site

1. Make changes locally
2. Commit and push to GitHub:
```bash
git add .
git commit -m "Update: description of changes"
git push
```
3. Vercel automatically rebuilds and deploys!

## Custom Domain Setup

### Using Namecheap, GoDaddy, or other registrars:

1. Go to Vercel → Your Project → Settings → Domains
2. Add your domain (e.g., `piyushgupta.com`)
3. Vercel will provide DNS records
4. Add these records to your domain registrar:
   - **Type**: A
   - **Name**: @
   - **Value**: 76.76.21.21
   
   - **Type**: CNAME
   - **Name**: www
   - **Value**: cname.vercel-dns.com

5. Wait for DNS propagation (up to 48 hours, usually faster)

## SSL Certificate

Vercel automatically provides free SSL certificates! Your site will be:
- ✅ Secure (HTTPS)
- ✅ Fast (Global CDN)
- ✅ Reliable (99.99% uptime)

## Monitoring

### Check Deployment Status

```bash
vercel ls
```

### View Logs

```bash
vercel logs <deployment-url>
```

### Check Domain Status

```bash
vercel domains ls
```

## Best Practices

1. **Always test locally first**
   ```bash
   npm run build
   npm run preview
   ```

2. **Use meaningful commit messages**
   ```bash
   git commit -m "feat: Add new skill to Skills section"
   git commit -m "fix: Correct email validation"
   git commit -m "style: Update hero section colors"
   ```

3. **Keep dependencies updated**
   ```bash
   npm outdated
   npm update
   ```

4. **Use environment variables for sensitive data**
   - Never commit API keys
   - Store in Vercel environment variables

## Support

- **Vercel Docs**: https://vercel.com/docs
- **Vercel Community**: https://github.com/vercel/vercel/discussions
- **Portfolio Issues**: Check your GitHub repository issues

---

## Quick Reference

```bash
# Deploy to development
vercel

# Deploy to production
vercel --prod

# Check deployments
vercel ls

# Remove deployment
vercel rm <deployment-name>

# Check logs
vercel logs
```

---

🎉 **Congratulations!** Your portfolio is now live and accessible worldwide!

Share your link:
- Add to GitHub profile README
- Share on LinkedIn
- Add to resume
- Share on social media

---

**Need help?** Open an issue on GitHub or contact via the portfolio contact form!