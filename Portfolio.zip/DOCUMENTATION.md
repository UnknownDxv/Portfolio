# 📋 Project Documentation

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Component Breakdown](#component-breakdown)
4. [Styling Guide](#styling-guide)
5. [Development Workflow](#development-workflow)
6. [Customization](#customization)

---

## Overview

**Unknown Portfolio** is a professional developer portfolio built with modern web technologies. It features:

- ⚡ Lightning-fast performance with Vite
- 🎨 Beautiful dark theme with gaming aesthetics
- 📱 Fully responsive design
- ♿ Accessible and SEO-friendly
- 🎭 Smooth animations with Framer Motion

### Key Metrics
- **Lighthouse Score**: Target 95+
- **Bundle Size**: ~150KB (gzipped)
- **First Contentful Paint**: < 1s
- **Time to Interactive**: < 2s

---

## Architecture

### Tech Stack Decision

```
Frontend Framework: React 18
├─ Why: Component reusability, virtual DOM, large ecosystem
├─ Type Safety: TypeScript
├─ Build Tool: Vite (faster than CRA, better DX)
├─ Styling: CSS Modules (scoped, no runtime overhead)
└─ Animations: Framer Motion (declarative, performant)
```

### Project Structure

```
portfolio-project/
│
├── public/                 # Static assets
│
├── src/
│   ├── components/        # React components
│   │   ├── Navbar/       # Navigation with hamburger menu
│   │   ├── Hero/         # Landing section with typing effect
│   │   ├── About/        # About me section
│   │   ├── Skills/       # Skills showcase (no progress bars)
│   │   ├── Contact/      # Contact form with validation
│   │   └── Footer/       # Footer with links
│   │
│   ├── pages/            # Page components
│   │   └── Home.tsx      # Main page combining all sections
│   │
│   ├── assets/           # Images, icons
│   │   ├── images/
│   │   └── icons/
│   │
│   ├── styles/           # Global styles
│   │   └── global.css    # CSS variables, utilities, animations
│   │
│   ├── App.tsx           # Root component
│   └── main.tsx          # Entry point
│
├── index.html            # HTML template
├── package.json          # Dependencies
├── tsconfig.json         # TypeScript config
├── vite.config.ts        # Vite config
└── vercel.json          # Deployment config
```

---

## Component Breakdown

### 1. Navbar Component

**Purpose**: Fixed navigation with hamburger menu

**Features**:
- Sticky header with scroll effect
- 3-line hamburger menu animation
- Slide-in mobile menu
- Smooth section scrolling
- Social links

**Props**: None (self-contained)

**State**:
```tsx
- isOpen: boolean          // Menu open/closed
- scrolled: boolean        // Navbar background on scroll
```

**Key Files**:
- `src/components/Navbar.tsx`
- `src/components/Navbar.css`

---

### 2. Hero Component

**Purpose**: Landing section with dynamic content

**Features**:
- Animated typing effect (4 roles)
- Profile image with glow effect
- CTA buttons
- Social links
- Scroll indicator

**State**:
```tsx
- typedText: string        // Current typed text
- currentRoleIndex: number // Which role is being typed
- isDeleting: boolean      // Typing or deleting
```

**Animation Loop**:
1. Type full role
2. Pause 2s
3. Delete role
4. Move to next role
5. Repeat

**Key Files**:
- `src/components/Hero.tsx`
- `src/components/Hero.css`

---

### 3. About Component

**Purpose**: Professional introduction

**Structure**:
- Main description card
- 3 specialty cards (Bot Dev, Backend, Gaming)
- Philosophy section

**Features**:
- Grid layout (responsive)
- Hover effects on cards
- Icon animations
- Check marks for highlights

**Key Files**:
- `src/components/About.tsx`
- `src/components/About.css`

---

### 4. Skills Component

**Purpose**: Display technical skills

**IMPORTANT**: NO progress bars or percentages!

**Design**:
- ✓ Checklist style
- Material Icons
- Two categories:
  1. Programming Languages
  2. Tools & Technologies
- Core Competencies grid

**Features**:
- Hover scale effect
- Icon rotation on hover
- Staggered animations
- Clean, professional look

**Key Files**:
- `src/components/Skills.tsx`
- `src/components/Skills.css`

---

### 5. Contact Component

**Purpose**: Contact form with validation

**Features**:
- Real-time validation
- Custom error messages
- Success notification
- Social links
- Contact info cards

**Form Fields**:
```tsx
- name: string     // Min 2 chars
- email: string    // Valid email format
- message: string  // Min 10 chars
```

**Validation Rules**:
- All fields required
- Email: regex pattern
- Name: min 2 characters
- Message: min 10 characters

**Key Files**:
- `src/components/Contact.tsx`
- `src/components/Contact.css`

---

### 6. Footer Component

**Purpose**: Footer with links and info

**Sections**:
- Brand (logo + tagline)
- Quick links
- Social links
- Copyright

**Features**:
- Grid layout
- Hover effects
- Heartbeat animation on ❤️
- Responsive design

**Key Files**:
- `src/components/Footer.tsx`
- `src/components/Footer.css`

---

## Styling Guide

### CSS Architecture

**Structure**:
```
Global Styles (global.css)
├─ CSS Reset
├─ CSS Variables
├─ Typography
├─ Utility Classes
├─ Animations
└─ Responsive Breakpoints

Component Styles (*.css)
├─ Component-specific
├─ BEM-like naming
└─ Scoped to component
```

### CSS Variables

```css
/* Colors */
--bg-primary: #0a0e27;
--bg-secondary: #10163a;
--accent-primary: #00d9ff;
--accent-secondary: #7000ff;

/* Spacing */
--spacing-xs: 0.5rem;
--spacing-sm: 1rem;
--spacing-md: 2rem;
--spacing-lg: 4rem;

/* Typography */
--font-primary: 'Inter', sans-serif;
--font-mono: 'Fira Code', monospace;
```

### Responsive Breakpoints

```css
/* Mobile */
@media (max-width: 576px) { }

/* Tablet */
@media (max-width: 768px) { }

/* Laptop */
@media (max-width: 992px) { }

/* Desktop */
@media (max-width: 1200px) { }
```

### Animation System

```css
/* Fade In */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Slide In */
@keyframes slideInLeft {
  from { opacity: 0; transform: translateX(-50px); }
  to { opacity: 1; transform: translateX(0); }
}

/* Pulse */
@keyframes pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}
```

---

## Development Workflow

### Initial Setup

```bash
# 1. Clone and install
git clone <repo>
cd portfolio-project
npm install

# 2. Start dev server
npm run dev

# 3. Open browser
# http://localhost:3000
```

### Making Changes

```bash
# 1. Create feature branch
git checkout -b feature/new-section

# 2. Make changes
# Edit files...

# 3. Test locally
npm run build
npm run preview

# 4. Commit changes
git add .
git commit -m "feat: Add new section"

# 5. Push to GitHub
git push origin feature/new-section

# 6. Create pull request
# GitHub will show preview deployment (Vercel)
```

### Code Quality

```bash
# Lint code
npm run lint

# Type check
npx tsc --noEmit

# Format (if using Prettier)
npx prettier --write .
```

---

## Customization

### 1. Change Colors

Edit `src/styles/global.css`:

```css
:root {
  --accent-primary: #YOUR_COLOR;
  --accent-secondary: #YOUR_COLOR;
}
```

### 2. Update Content

#### Hero Section
- File: `src/components/Hero.tsx`
- Update: Name, roles, tagline, social links

#### About Section
- File: `src/components/About.tsx`
- Update: Description, cards, philosophy

#### Skills Section
- File: `src/components/Skills.tsx`
- Update: Skills arrays, competencies

#### Contact Section
- File: `src/components/Contact.tsx`
- Update: Social links, email, location

### 3. Add New Section

```tsx
// 1. Create component
// src/components/NewSection.tsx
import React from 'react';
import './NewSection.css';

const NewSection: React.FC = () => {
  return (
    <section id="new-section" className="new-section section">
      {/* Content */}
    </section>
  );
};

export default NewSection;

// 2. Add to Home page
// src/pages/Home.tsx
import NewSection from '../components/NewSection';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <About />
      <Skills />
      <NewSection /> {/* Add here */}
      <Contact />
    </>
  );
};

// 3. Add to navigation
// src/components/Navbar.tsx
const navItems = [
  // ...
  { name: 'New Section', href: '#new-section' },
];
```

### 4. Change Fonts

Update `index.html`:

```html
<!-- Add Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=YOUR_FONT&display=swap" rel="stylesheet">
```

Update `global.css`:

```css
:root {
  --font-primary: 'YOUR_FONT', sans-serif;
}
```

### 5. Add Images

```tsx
// 1. Add image to src/assets/images/
// 2. Import in component
import myImage from '../assets/images/my-image.jpg';

// 3. Use in JSX
<img src={myImage} alt="Description" />
```

---

## Performance Tips

### 1. Image Optimization
- Compress images (< 200KB each)
- Use WebP format when possible
- Lazy load images below fold

### 2. Code Splitting
```tsx
// Lazy load heavy components
const HeavyComponent = lazy(() => import('./HeavyComponent'));
```

### 3. Bundle Analysis
```bash
npm run build
npx vite-bundle-visualizer
```

### 4. Lighthouse Audit
- Open DevTools
- Run Lighthouse
- Fix issues
- Target: 95+ score

---

## Troubleshooting

### Issue: Port 3000 already in use
```bash
# Kill process
lsof -ti:3000 | xargs kill -9

# Or use different port
npm run dev -- --port 3001
```

### Issue: Build fails
```bash
# Clear cache
rm -rf node_modules
rm package-lock.json
npm install

# Rebuild
npm run build
```

### Issue: Animations not working
- Check Framer Motion installation
- Verify import statements
- Check browser console for errors

---

## Resources

- **React Docs**: https://react.dev
- **TypeScript**: https://typescriptlang.org
- **Vite**: https://vitejs.dev
- **Framer Motion**: https://framer.com/motion
- **Material Icons**: https://fonts.google.com/icons

---

## Support

For issues or questions:
1. Check this documentation
2. Review component comments
3. Check GitHub issues
4. Open new issue with details

---

**Happy Coding! 🚀**